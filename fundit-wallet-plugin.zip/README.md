# Fundit Wallet Plugin
This plugin implements a virtual wallet system for CrowdSpender, allowing users to manage and pledge Fundits.
